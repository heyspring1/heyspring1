//탭 이벤트

var changeNum = 1; // 증가, 감소 버튼 위한 전역변수 선언 (int)

function tabChange(num){

    $(".tab_on").attr("class",'tab');
    $("#tab_" + num).attr("class",'tab_on');

    changeNum = parseInt(num); // 여기서 num이 (string) 이여서 변수 대입이 안되므로 (int)로 형변환

    if(num == '1'){
        $(".tab_box"+ num ).css("display",'block');

        $(".tab_box2").css("display",'none');
        $(".tab_box3").css("display",'none');
        $(".tab_box4").css("display",'none');
        $(".tab_box5").css("display",'none');
        $(".tab_box6").css("display",'none');
    }
    else if(num == '2'){
        $(".tab_box"+ num ).css("display",'block');

        $(".tab_box1").css("display",'none');
        $(".tab_box3").css("display",'none');
        $(".tab_box4").css("display",'none');
        $(".tab_box5").css("display",'none');
        $(".tab_box6").css("display",'none');
    }    
    else if(num == '3'){
        $(".tab_box"+ num ).css("display",'block');

        $(".tab_box2").css("display",'none');
        $(".tab_box1").css("display",'none');
        $(".tab_box4").css("display",'none');
        $(".tab_box5").css("display",'none');
        $(".tab_box6").css("display",'none');
    }    
    else if(num == '4'){
        $(".tab_box"+ num ).css("display",'block');

        $(".tab_box2").css("display",'none');
        $(".tab_box3").css("display",'none');
        $(".tab_box1").css("display",'none');
        $(".tab_box5").css("display",'none');
        $(".tab_box6").css("display",'none');
    }    
    else if(num == '5'){
        $(".tab_box"+ num ).css("display",'block');

        $(".tab_box2").css("display",'none');
        $(".tab_box3").css("display",'none');
        $(".tab_box4").css("display",'none');
        $(".tab_box1").css("display",'none');
        $(".tab_box6").css("display",'none');
    }    
    else if(num == '6'){
        $(".tab_box"+ num ).css("display",'block');

        $(".tab_box2").css("display",'none');
        $(".tab_box3").css("display",'none');
        $(".tab_box4").css("display",'none');
        $(".tab_box5").css("display",'none');
        $(".tab_box1").css("display",'none');
    }

}

function numChange(type){ // type , num은 변수임 암거나 해도 상관없음

    if(type == '1'){
        if(changeNum == 6){ // 최댓값 방지
            return;
        }
        else{
            num = changeNum + 1;
            tabChange(num);
        }
    }
    else{
        if(changeNum == 1){ // 0 방지
            return;
        }
        num = changeNum - 1;
        tabChange(num);
    }
}